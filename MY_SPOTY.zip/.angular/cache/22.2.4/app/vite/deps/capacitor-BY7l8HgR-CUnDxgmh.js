import { w as win } from "./helpers-p94IkmEA-5uAy2AkJ.js";
//#region node_modules/@ionic/core/dist/esm/capacitor-BY7l8HgR.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
var getCapacitor = () => {
	if (win !== void 0) return win.Capacitor;
};
//#endregion
export { getCapacitor as t };
