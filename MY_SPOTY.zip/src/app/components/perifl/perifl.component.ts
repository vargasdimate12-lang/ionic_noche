import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perifl',
  templateUrl: './perifl.component.html',
  styleUrls: ['./perifl.component.scss'],
  standalone: false,
})
export class PeriflComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
