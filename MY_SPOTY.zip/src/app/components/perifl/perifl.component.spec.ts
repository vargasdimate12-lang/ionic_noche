import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular/lazy';

import { PeriflComponent } from './perifl.component';

describe('PeriflComponent', () => {
  let component: PeriflComponent;
  let fixture: ComponentFixture<PeriflComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PeriflComponent],
      imports: [IonicModule.forRoot()],
    });

    fixture = TestBed.createComponent(PeriflComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
